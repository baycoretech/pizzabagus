﻿/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'ug', {
	bold: 'توم',
	italic: 'يانتۇ',
	strike: 'ئۆچۈرۈش سىزىقى',
	subscript: 'تۆۋەن ئىندېكس',
	superscript: 'يۇقىرى ئىندېكس',
	underline: 'ئاستى سىزىق'
} );
