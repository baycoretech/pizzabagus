﻿"use strict"

CKEDITOR.plugins.setLang( 'btgrid', 'ru', {
	selNumCols: 'Выберите количество колонок',
  genNrRows: 'Количество рядов',
	infoTab: 'Информация',
	createBtGrid: 'Создать сетку Bootstrap',
	editBtGrid: 'Редактировать сетку Bootstrap',
	numColsError:  'Выберите количество колонок, пожалуйста.',
	numRowsError: 'Введите числовое значение для Количества рядов, пожалуйста.',
} );
