﻿/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'ko', {
	ltr: '텍스트 방향이 왼쪽에서 오른쪽으로 ',
	rtl: '텍스트 방향이 오른쪽에서 왼쪽으로'
} );
