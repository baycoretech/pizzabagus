﻿/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'eu', {
	copy: 'Copyright &copy; $1. Eskubide guztiak erreserbaturik.',
	dlgTitle: 'CKEditor-i buruz',
	help: 'Begiratu $1 laguntzarako.',
	moreInfo: 'Lizentziari buruzko informazioa gure webgunean:',
	title: 'CKEditor-i buruz',
	userGuide: 'CKEditor-en erabiltzaile-gida'
} );
