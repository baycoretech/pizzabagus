﻿/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'gl', {
	copy: 'Copyright &copy; $1. Todos os dereitos reservados.',
	dlgTitle: 'Sobre o CKEditor',
	help: 'Consulte $1 para obter axuda.',
	moreInfo: 'Para obter  información sobre a licenza, visite o noso sitio web:',
	title: 'Sobre o CKEditor',
	userGuide: 'Guía do usuario do CKEditor'
} );
